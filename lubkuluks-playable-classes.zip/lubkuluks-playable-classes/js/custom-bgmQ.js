ig.module("impact.feature.bgm.bgm-ljm")
  .requires("impact.feature.bgm.bgm")
  .defines(function () {
    ig.merge(ig.BGM_TRACK_LIST, {
      tobyTheme: {
        path: "media/bgm/tobyTheme-loop.ogg",
        loopEnd: 237.205,
        volume: 1.0
      },
      emilieTheme: {
        path: "media/bgm/emilieTheme-loop.ogg",
        loopEnd: 131.226,
        volume: 1.0,
        introPath: "media/bgm/emilieTheme-i.ogg",
        introEnd: 2.528
      },
      millionThoughts: {
        path: "media/bgm/millionThoughts.ogg",
        loopEnd: 131.476,
        volume: 1.0,
        introPath: "media/bgm/millionThoughts-i-short.ogg",
        introEnd: 19.594
      },
      crystalized: {
        path: "media/bgm/crystalized.ogg",
        loopEnd: 213.572,
        volume: 0.8,
        introPath: "media/bgm/crystalized-i.ogg",
        introEnd: 21.711
      },
      protocol: {
        path: "media/bgm/protocol-loop.ogg",
        loopEnd: 76.852,
        volume: 0.8,
        introPath: "media/bgm/protocol-i.ogg",
        introEnd: 12.961
      },
      gunsBlazing: {
        path: "media/bgm/gunsBlazing-loop.ogg",
        loopEnd: 126.762,
        volume: 0.8,
        introPath: "media/bgm/gunsBlazing-i.ogg",
        introEnd: 2.684
      },
      enemyRetreating: {
        path: "media/bgm/enemy-retreating-loop.ogg",
        loopEnd: 76.771,
        volume: 0.8,
        introPath: "media/bgm/enemy-retreating-i.ogg",
        introEnd: 7.786
      },
      endOfTheLine: {
        path: "media/bgm/endOfTheLine-loop.ogg",
        loopEnd: 90.791,
        volume: 0.8,
        introPath: "media/bgm/endOfTheLine-i.ogg",
        introEnd: 5.317
      },
      tutorialSession: {
        path: "media/sound/roa/session-loop.ogg",
        loopEnd: 44.418,
        volume: 0.8,
      },
      tutorialActive: {
        path: "media/sound/roa/session-active-loop.ogg",
        loopEnd: 44.340,
        volume: 0.8,
      },
      vega: {
        path: "media/bgm/vega.ogg",
        loopEnd: 179.182,
        volume: 0.8,
        introPath: "media/bgm/vega-i.ogg",
        introEnd: 24.611
      }
    });

    ig.merge(ig.BGM_DEFAULT_TRACKS, {
    });
  });