//Starcaller
sc.STAT_PARAM_TYPE.ASSAULT = {
        key: "ASSAULT"
    };
sc.STAT_PARAM_TYPE.CRITICAL_DMG = {
        key: "CRITICAL_DMG"
    };
sc.STAT_PARAM_TYPE.COND_EFFECT_HEAT = {
        key: "COND_EFFECT_HEAT"
    };
sc.STAT_PARAM_TYPE.COND_EFFECT_ALL = {
        key: "COND_EFFECT_ALL"
    };
sc.STAT_PARAM_TYPE.COND_GUARD_HEAT = {
        key: "COND_GUARD_HEAT"
    };
sc.STAT_PARAM_TYPE.COND_GUARD_COLD = {
        key: "COND_GUARD_COLD"
    };
sc.STAT_PARAM_TYPE.COND_GUARD_SHOCK = {
        key: "COND_GUARD_SHOCK"
    };
sc.STAT_PARAM_TYPE.COND_GUARD_WAVE = {
        key: "COND_GUARD_WAVE"
    };
sc.STAT_CHANGE_SETTINGS["DASH-STEP-INFINITE"] = {
        change: sc.STAT_CHANGE_TYPE.MODIFIER,
        type: sc.STAT_PARAM_TYPE.DASH_STEP,
        value: 99,
        icon: "stat-dash",
        grade: "stat-rank-4"
    };
sc.STAT_CHANGE_SETTINGS["ASSAULT-001"] = {
        change: sc.STAT_CHANGE_TYPE.MODIFIER,
        type: sc.STAT_PARAM_TYPE.ASSAULT,
        value: 0.1,
        icon: "stat-attack",
        grade: "stat-rank-4"
    };
sc.STAT_CHANGE_SETTINGS["RANGED_DMG-001"] = {
        change: sc.STAT_CHANGE_TYPE.MODIFIER,
        type: sc.STAT_PARAM_TYPE.RANGED_DMG,
        value: 0.1,
        icon: "stat-attack",
        grade: "stat-rank-4"
    };
sc.STAT_CHANGE_SETTINGS["RANGED_DMG-00075"] = {
        change: sc.STAT_CHANGE_TYPE.MODIFIER,
        type: sc.STAT_PARAM_TYPE.RANGED_DMG,
        value: 0.075,
        icon: "stat-attack",
        grade: "stat-rank-4"
    };
sc.STAT_CHANGE_SETTINGS["BREAK_DMG-001"] = {
        change: sc.STAT_CHANGE_TYPE.MODIFIER,
        type: sc.STAT_PARAM_TYPE.BREAK_DMG,
        value: 0.2,
        icon: "stat-attack",
        grade: "stat-rank-4"
    };
sc.STAT_CHANGE_SETTINGS["CRITICAL_DMG-003"] = {
        change: sc.STAT_CHANGE_TYPE.MODIFIER,
        type: sc.STAT_PARAM_TYPE.CRITICAL_DMG,
        value: 0.3,
        icon: "stat-attack",
        grade: "stat-rank-4"
    };
sc.STAT_CHANGE_SETTINGS["COND_EFFECT_HEAT-003"] = {
        change: sc.STAT_CHANGE_TYPE.MODIFIER,
        type: sc.STAT_PARAM_TYPE.COND_EFFECT_HEAT,
        value: 0.3,
        icon: "stat-attack",
        grade: "stat-rank-4"
    };
sc.STAT_CHANGE_SETTINGS["COND_EFFECT_ALL-001"] = {
        change: sc.STAT_CHANGE_TYPE.MODIFIER,
        type: sc.STAT_PARAM_TYPE.COND_EFFECT_HEAT,
        value: 0.1,
        icon: "stat-attack",
        grade: "stat-rank-4"
    };
sc.STAT_CHANGE_SETTINGS["MELEE_DMG-0008"] = {
        change: sc.STAT_CHANGE_TYPE.MODIFIER,
        type: sc.STAT_PARAM_TYPE.RANGED_DMG,
        value: 0.08,
        icon: "stat-attack",
        grade: "stat-rank-4"
    };
sc.STAT_CHANGE_SETTINGS["SPIKE_DMG-003"] = {
        change: sc.STAT_CHANGE_TYPE.MODIFIER,
        type: sc.STAT_PARAM_TYPE.SPIKE_DMG,
        value: 0.3,
        icon: "stat-attack",
        grade: "stat-rank-4"
    };
sc.STAT_CHANGE_SETTINGS["HP_REGEN-0015"] = {
        change: sc.STAT_CHANGE_TYPE.MODIFIER,
        type: sc.STAT_PARAM_TYPE.HP_REGEN,
        value: 0.15,
        icon: "stat-attack",
        grade: "stat-rank-4"
    };
sc.STAT_CHANGE_SETTINGS["COND_GUARD_HEAT-001"] = {
        change: sc.STAT_CHANGE_TYPE.MODIFIER,
        type: sc.STAT_PARAM_TYPE.COND_GUARD_HEAT,
        value: 0.1,
        icon: "stat-attack",
        grade: "stat-rank-4"
    };
sc.STAT_CHANGE_SETTINGS["COND_GUARD_COLD-001"] = {
        change: sc.STAT_CHANGE_TYPE.MODIFIER,
        type: sc.STAT_PARAM_TYPE.COND_GUARD_COLD,
        value: 0.1,
        icon: "stat-attack",
        grade: "stat-rank-4"
    };
sc.STAT_CHANGE_SETTINGS["COND_GUARD_SHOCK-001"] = {
        change: sc.STAT_CHANGE_TYPE.MODIFIER,
        type: sc.STAT_PARAM_TYPE.COND_GUARD_SHOCK,
        value: 0.1,
        icon: "stat-attack",
        grade: "stat-rank-4"
    };
sc.STAT_CHANGE_SETTINGS["COND_GUARD_WAVE-001"] = {
        change: sc.STAT_CHANGE_TYPE.MODIFIER,
        type: sc.STAT_PARAM_TYPE.COND_GUARD_WAVE,
        value: 0.1,
        icon: "stat-attack",
        grade: "stat-rank-4"
    };


//Quadroguard
sc.STAT_PARAM_TYPE.AIM_SPEED = {
        key: "AIM_SPEED"
    };
    sc.STAT_CHANGE_SETTINGS["EMPOWERED-SCOPE"] = {
  change: sc.STAT_CHANGE_TYPE.MODIFIER,
  type: sc.STAT_PARAM_TYPE.AIM_SPEED,
  value: 10,
  icon: "stat-ranged",
  grade: "stat-rank-4"
};
sc.STAT_CHANGE_SETTINGS["EMPOWERED-OVERHEAT-REDUCTION"] = {
  change: sc.STAT_CHANGE_TYPE.MODIFIER,
  type: sc.STAT_PARAM_TYPE.OVERHEAT,
  value: 0.5,
  icon: "stat-overheat",
  grade: "stat-rank-4"
};
sc.STAT_CHANGE_SETTINGS["EMPOWERED-DEFENSE-SCALING"] = {
  change: sc.STAT_CHANGE_TYPE.STATS,
  type: sc.STAT_PARAM_TYPE.ATTACK,
  value: 1,
  icon: "stat-attack",
  grade: "stat-rank-1"
};
sc.STAT_CHANGE_SETTINGS["DEFENSE-MINUS-ASHEN"] = {
  change: sc.STAT_CHANGE_TYPE.STATS,
  type: sc.STAT_PARAM_TYPE.DEFENSE,
  value: 0.75,
  negative: true,
  icon: "stat-attack",
  grade: "stat-rank-down-2"
};

sc.STAT_CHANGE_SETTINGS["AVENGER-ADD"] = {
  change: sc.STAT_CHANGE_TYPE.MODIFIER,
  type: sc.STAT_PARAM_TYPE.GUARD_SP,
  value: 1,
  icon: "stat-attack",
  grade: "stat-rank-4"
};

sc.STAT_CHANGE_SETTINGS["ROYAL-GUARD-ADD"] = {
  change: sc.STAT_CHANGE_TYPE.MODIFIER,
  type: sc.STAT_PARAM_TYPE.PERFECT_GUARD_WINDOW,
  value: 1,
  icon: "stat-defense",
  grade: "stat-rank-1"
};

sc.STAT_CHANGE_SETTINGS["RIPOSTE-ENABLE"] = {
  change: sc.STAT_CHANGE_TYPE.MODIFIER,
  type: sc.STAT_PARAM_TYPE.PERFECT_GUARD_RESET,
  value: 1,
  icon: "stat-hp",
  grade: "stat-rank-2"
};

sc.STAT_CHANGE_SETTINGS["SOLID-GUARD-MINUS"] = {
  change: sc.STAT_CHANGE_TYPE.MODIFIER,
  type: sc.STAT_PARAM_TYPE.GUARD_STRENGTH,
  value: 1,
  negative: true,
  icon: "stat-spike-dmg",
  grade: "stat-rank-down-3"
};