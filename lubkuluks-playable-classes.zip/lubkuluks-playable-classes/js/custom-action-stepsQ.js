ig.module("game.feature.combat.lqm-combat-action-steps").requires("game.feature.combat.combat-action-steps").defines(function() {
//Quadroguard
ig.ACTION_STEP.DO_ACTION = ig.ActionStepBase.extend({
        entity: 0,
        action: null,
        wait: false,
        keepState: false,
        _actionEntity: null,
        _wm: new ig.Config({
            attributes: {
                entity: {
                    _type: "Entity",
                    _info: "Entity to move",
                    _visualize: true,
                    _context: "Entity"
                },
                action: {
                    _type: "Action",
                    _info: "The action to perform",
                    _rec_visualize: ig.ACTION_STEP
                },
                repeating: {
                    _type: "Boolean",
                    _info: "Repeat Action"
                },
                wait: {
                    _type: "Boolean",
                    _info: "Wait until action is finished"
                },
                keepState: {
                    _type: "Boolean",
                    _info: "Don't reset entity state after action"
                },
                immediately: {
                    _type: "Boolean",
                    _info: "If true: execute action immediately not interrupting currently running action. Will only execute steps without wait duration."
                }
            },
            width: 500
        }),
        init: function (a) {
            assertContent(a, "entity", "action");
            this.entity = a.entity;
            this.action = new ig.Action("[GENERIC]", a.action, false, a.repeating);
            this.action.eventAction = true;
            this.wait = a.wait || false;
            this.keepState = a.keepState || false;
            this.immediately = a.immediately || false
        },
        clearCached: function () {
            this.action && this.action.clearCached()
        },
        start: function (a, b) {
            var c = ig.Event.getEntity(this.entity, b);
            a._actionEntity = c;
            if (this.immediately) {
                c.stashAction(true);
                c.setAction(this.action);
                c.forceExecuteAction();
                c.resumeStashedAction(true)
            } else
                c && c.setAction(this.action, this.keepState)
        },
        run: function (a) {
            return this.immediately || !a._actionEntity || !this.wait ? true : a._actionEntity.currentAction ==
            this.action || a._actionEntity.respawn && a._actionEntity.respawn.timer ? false : true
        }
    });
ig.ACTION_STEP.RESET_GUARDED_ATTACKS = ig.ActionStepBase.extend({
      init: function(a) {},
      start: function(a) {
          a = a.getCombatantRoot();
          a.combo.guardedHits = 0;
          a.combo.blockedDamage = 0;
          a.combo.blockedFactor = 0;
          a.combo.guardedEntity = null;
      }
  });
ig.ACTION_STEP.RESET_TARGET_BLOCKED_FACTOR = ig.ActionStepBase.extend({
      init: function(a) {},
      start: function(a) {
          a = a.getTarget();
          a.combo.blockedFactor = 0;
      }
  });
ig.ACTION_STEP.RESET_TARGET_GUARDED_HITS = ig.ActionStepBase.extend({
      init: function(a) {},
      start: function(a) {
          a = a.getTarget();
          a.combo.guardedHits = 0;
      }
  });
ig.ACTION_STEP.SHOW_SIDE_MSG = ig.ActionStepBase.extend({
        charExpression: null,
        message: null,
        hiCount: 0,
        _wm: new ig.Config({
            attributes: {
                person: {
                    _type: "PersonExpression",
                    _info: "Person + Exporession of message"
                },
                message: {
                    _type: "LangLabel",
                    _info: "Message to display",
                    _large: true
                }
            },
            label: function () {
                return "<b>SHOW_SIDE_MSG</b> <em>" + wmPrint("PersonExpression", this.person) + "</em>: <i>" + wmPrint("LangLabel", this.message) + "</i>"
            }
        }),
        init: function (a) {
            this.charExpression = new sc.CharacterExpression(a.person.person, a.person.expression);
            this.message = new ig.LangLabel(a.message);
            ig.langEdit && ig.langEdit.submitMap("Side MSG " + this.charExpression.character.name, this.message);
            if (this.charExpression.character.name ==
                "main.lea" && a.message && a.message.en_US)
                this.hiCount = (this.hiCount = a.message.en_US.match(/hi[.!?]/gi)) ? this.hiCount.length : 0
        },
        clearCached: function () {
            this.charExpression.decreaseRef()
        },
        start: function () {
            this.hiCount && sc.stats.addMap("misc", "hiCount", this.hiCount || 0);
            ig.langEdit && ig.langEdit.submitRecent("Side MSG " + this.charExpression.character.name, this.message);
            sc.model.message.showSideMessage(this.charExpression, this.message)
        }
    });

ig.ACTION_STEP.ADD_PLAYER_SHIELD_VAR = ig.ActionStepBase.extend({
        _wm: new ig.Config({
            attributes: {
                perfectGuard: {
                    _type: "Boolean",
                    _info: "If true: add perfect guard"
                }
            }
        }),
        init: function (a) {
            var b = {
                type: "PLAYER",
                settings: {
                    name: "playerShield",
                    baseFactor: 1,
                    strength: "BLOCK_ALL",
                    hitResist: "MASSIVE",
                    noShieldDamage: true,
                    stableOverride: "MASSIVE",
                    range: 0.5
                }
            };
            this.shield = new sc.COMBAT_SHIELDS[b.type](b.settings);
            this.perfectGuard = a.perfectGuard ||
                null
        },
        clearCached: function () {
            this.shield && this.shield.clearCached()
        },
        run: function (a) {
            var b = a.getCombatantRoot(),
            c = 0;
            this.perfectGuard && (c = 0.1 * (1 + b.params.getModifier("PERFECT_GUARD_WINDOW")));
            var d = b.params.getModifier("GUARD_AREA");
            this.shield.range = d >= 1 ? 1 : 0.5;
            this.shield.strength = d >= 2 ? sc.SHIELD_STRENGTH.BLOCK_ALL : sc.SHIELD_STRENGTH.BLOCK_ALL;
            b = b.addShield(this.shield, c);
            a.addActionAttached(b);
            return true
        }
    });
ig.ACTION_STEP.ABSORB_BLOCKED_DAMAGE_VAR = ig.ActionStepBase.extend({
        _wm: new ig.Config({
            attributes: {
                target: {
                    _type: "String",
                    _info: "What entity will get the buff",
                    _select: d,
                    _optional: true
                },
                factor: {
                    _type: "Number",
                    _info: "Factor with which to absorb blocked damage"
                }
            }
        }),
        init: function (a) {
            this.target = d[a.target] || d.SELF;
            this.factor = a.factor
        },
        start: function (a) {
            var b = {
                absolute: true,
                value: Math.round(a.combo.blockedDamage * this.factor)
            };
            (a = this.target(a)) && a.heal(b)
        }
    });
//Starcaller
ig.ACTION_STEP.SET_PLAYER_CORE = ig.ActionStepBase.extend({
        core: null,
        value: null,
        _wm: new ig.Config({
            attributes: {
                core: {
                    _type: "String",
                    _info: "Type of Core.",
                    _select: sc.PLAYER_CORE
                },
                value: {
                    _type: "Boolean",
                    _info: "True to activate core."
                }
            }
        }),
        init: function (b) {
            this.core = sc.PLAYER_CORE[b.core];
            this.value = b.value
        },
        start: function () {
            sc.model.player.setCore(this.core, this.value)
        }
    });
ig.ACTION_STEP.SPAWN_ASSAULT_FARTHER = ig.ActionStepBase.extend({
        _wm: new ig.Config({
            attributes: {
                baseStrength: {
                    _type: "Number",
                    _info: "Base Strength Factor. Should match damageFactor of attack"
                },
                element: {
                    _type: "String",
                    _info: "Element of Assault projectile",
                    _select: sc.ELEMENT,
                    _optional: true
                }
            }
        }),
        init: function (a) {
            this.baseStrength = a.baseStrength || 0;
            if (a.element)
                this.element = sc.ELEMENT[a.element]
        },
        run: function (a) {
            var b = this.element === void 0 ? sc.combat.getElementMode(a) : this.element;
            sc.AssaultToolsLSM.spawn(a, b, this.baseStrength);
            return true
        }
    });
ig.ACTION_STEP.UNLOCK_ENEMY = ig.ActionStepBase.extend({
        enemy: null,
        asSpecial: null,
        _wm: new ig.Config({
            attributes: {
                enemy: {
                    _type: "EnemySearch",
                    _info: "Enemy to unlock, note that this enemy, use this only for special enemies."
                },
                asSpecial: {
                    _type: "Boolean",
                    _info: "if true 'special' will be displayed instead of kill count",
                    _default: true
                }
            }
        }),
        init: function (b) {
            this.enemy = b.enemy;
            this.asSpecial = b.asSpecial == void 0 ? true : b.asSpecial
        },
        start: function () {
            sc.stats.setMap("combat",
                "kill" + this.enemy, this.asSpecial ? -1 : 1);
            sc.stats.setMap("combat", "enemyCompletionRate", sc.combat.getTotalEnemiesFound(true))
        }
    });
ig.ACTION_STEP.SET_SPIKE_DAMAGE_VAR = ig.ActionStepBase.extend({
        value: null,
        _wm: new ig.Config({
            attributes: {
                value: {
                    _type: "NumberExpression",
                    _info: "Value for spike damage factor"
                }
            }
        }),
        init: function (a) {
            this.value =
                a.value
        },
        run: function (a) {
            var s = ig.Event.getExpressionValue(this.value)
            a.spikeDmg.tmpFactor = s;
            return true
        }
    });
var d = {
        SELF: function (a) {
            return a
        },
        PROXY_OWNER: function (a) {
            return a.getCombatantRoot()
        },
        PROXY_SRC: function (a) {
            return a.sourceEntity
        },
        TARGET: function (a) {
            return a.getTarget()
        }
    };

var C = {
        set: function (a, b) {
            return b
        },
        mul: function (a, b) {
            return a * b
        }
    };
ig.ACTION_STEP.MOD_ACTION_BUFF_PARAM = ig.ActionStepBase.extend({
        _wm: new ig.Config({
            attributes: {
                target: {
                    _type: "String",
                    _info: "What entity will get the buff",
                    _select: d
                },
                name: {
                    _type: "String",
                    _info: "Name used to search for buff of target entity"
                },
                param: {
                    _type: "String",
                    _info: "What param to modify",
                    _select: ["hp",
                        "attack", "defense", "focus"]
                },
                changeType: {
                    _type: "String",
                    _info: "Type of modification",
                    _select: C
                },
                value: {
                    _type: "NumberExpression",
                    _info: "By what value param is modified"
                }
            }
        }),
        init: function (a) {
            this.target = d[a.target] || d.SELF;
            this.name = a.name || null;
            this.param = a.param;
            this.value = a.value || 0;
            this.changeType = C[a.changeType] || C.set
        },
        start: function (a) {
            if ((a = this.target(a)) && a.params)
                for (var b = a.params.buffs, c = b.length; c--; ) {
                    var d = b[c];
                    if (d instanceof sc.ActionBuff && d.name == this.name) {
                        var z = ig.Event.getExpressionValue(this.value);
                        var e = this.changeType(d.params[this.param], z);
                        a.params.modifyBuff(d, this.param, e)
                    }
                }
        }
    });
});