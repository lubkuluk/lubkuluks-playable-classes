ig.module("game.feature.font.lqm-custom-icons").requires("game.feature.font.font-system").defines(function() {
	var fontIdx = sc.fontsystem.font.iconSets.length, smallFontIdx = sc.fontsystem.smallFont.iconSets.length;
	
	sc.fontsystem.font.pushIconSet(new ig.Font("media/font/lqm-font-icons.png", 16, ig.MultiFont.ICON_START));
	
	//large font icons Quadroguard
	sc.fontsystem.font.setMapping({"class-scaller" :[fontIdx, 0]});
	sc.fontsystem.font.setMapping({"class-blu-tri" :[fontIdx, 3]});
	sc.fontsystem.font.setMapping({"class-blu-hex" :[fontIdx, 6]});

	//small font icons
});
