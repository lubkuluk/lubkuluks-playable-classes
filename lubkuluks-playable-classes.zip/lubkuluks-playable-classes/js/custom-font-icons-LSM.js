ig.module("game.feature.font.lsm-custom-icons").requires("game.feature.font.font-system").defines(function() {
	var fontIdx = sc.fontsystem.font.iconSets.length,
	smallFontIdx = sc.fontsystem.smallFont.iconSets.length;
	
	sc.fontsystem.font.pushIconSet(new ig.Font("media/font/lsm-font-icons.png", 16, ig.MultiFont.ICON_START));
	sc.fontsystem.smallFont.pushIconSet(new ig.Font("media/font/lsm-font-icons-small.png", 14, ig.MultiFont.ICON_START));
	
	//large font icons
	sc.fontsystem.font.setMapping({"enemy-allies" :[fontIdx, 1]});

	//small font icons
	sc.fontsystem.smallFont.setMapping({"stat-small-attack" :[smallFontIdx, 0]});
	sc.fontsystem.smallFont.setMapping({"stat-small-hp" :[smallFontIdx, 1]});
	sc.fontsystem.smallFont.setMapping({"stat-small-defense" :[smallFontIdx, 2]});
	sc.fontsystem.smallFont.setMapping({"stat-small-focus" :[smallFontIdx, 3]});
	sc.fontsystem.smallFont.setMapping({"stat-small-assault" :[smallFontIdx, 4]});
	sc.fontsystem.smallFont.setMapping({"stat-small-bullseye" :[smallFontIdx, 5]});
	sc.fontsystem.smallFont.setMapping({"stat-small-shooter" :[smallFontIdx, 6]});
	sc.fontsystem.smallFont.setMapping({"stat-small-bouncer" :[smallFontIdx, 7]});
	sc.fontsystem.smallFont.setMapping({"stat-small-burn-rush" :[smallFontIdx, 8]});
	sc.fontsystem.smallFont.setMapping({"stat-small-status-rush" :[smallFontIdx, 9]});
	sc.fontsystem.smallFont.setMapping({"stat-small-brawler" :[smallFontIdx, 10]});
	sc.fontsystem.smallFont.setMapping({"stat-small-pin-body" :[smallFontIdx, 11]});
	sc.fontsystem.smallFont.setMapping({"stat-small-hp-regen" :[smallFontIdx, 12]});
	sc.fontsystem.smallFont.setMapping({"stat-small-status-mend" :[smallFontIdx, 13]});
	sc.fontsystem.smallFont.setMapping({"element-poison" :[smallFontIdx, 14]});
	sc.fontsystem.smallFont.setMapping({"element-dark" :[smallFontIdx, 15]});
	sc.fontsystem.smallFont.setMapping({"element-radiant" :[smallFontIdx, 16]});
	sc.fontsystem.smallFont.setMapping({"element-water" :[smallFontIdx, 17]});
	sc.fontsystem.smallFont.setMapping({"element-earth" :[smallFontIdx, 18]});
});
