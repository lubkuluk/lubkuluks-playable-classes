sc.EnemyListBox.inject({
  submitSound: null,
        favSound: null,
        errorSound: null,
        enemies: null,
        init: function () {
            this.parent(true);
            this.setSize(264, 262);
            this.setAlign(ig.GUI_ALIGN.X_RIGHT, ig.GUI_ALIGN.Y_TOP);
            this.setPivot(264, 262);
            this.setPanelSize(264, 243);
            this.favSound = this.submitSound = sc.BUTTON_SOUND.submit;
            this.errorSound = sc.BUTTON_SOUND.denied;
            this.hook.transitions = {
                DEFAULT: {
                    state: {},
                    time: 0.2,
                    timeFunction: KEY_SPLINES.LINEAR
                },
                HIDDEN: {
                    state: {
                        alpha: 0,
                        offsetX: -132
                    },
                    time: 0.2,
                    timeFunction: KEY_SPLINES.LINEAR
                },
                HIDDEN_EASE: {
                    state: {
                        alpha: 0,
                        offsetX: -132
                    },
                    time: 0.2,
                    timeFunction: KEY_SPLINES.EASE
                }
            };
            this.enemies = ig.database.get("enemies");
            var b = new sc.TextGui(ig.lang.get("sc.gui.status-hud.lvl"), {
                font: sc.fontsystem.tinyFont
            });
            b.setAlign(ig.GUI_ALIGN.X_RIGHT, ig.GUI_ALIGN.Y_TOP);
            b.setPos(7, -8);
            this.bg.addChildGui(b);
            this.addTab("allies", 5, {
                type: sc.ENEMY_CATEGORY.ALLIES
            })
        },
        getEnemyCategoryKey: function (b) {
            switch (sc.ENEMY_CATEGORY[b]) {
            case sc.ENEMY_CATEGORY.ANIMALS:
                return "animals";
            case sc.ENEMY_CATEGORY.MECHA:
                return "mecha";
            case sc.ENEMY_CATEGORY.PLAYERS:
                return "avatars";
            case sc.ENEMY_CATEGORY.ABSTRACT:
                return "abstract";
            case sc.ENEMY_CATEGORY.ALLIES:
                return "allies"
            }
        },
});