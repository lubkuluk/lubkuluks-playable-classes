ig.module("game.feature.player.entities.player-injection").requires("game.feature.player.entities.player", "game.feature.player.player-config").defines(function() {
    ig.ENTITY.Player.inject({
        attackCounterLoop: -1,
        maxAttackCount: 3,
		counterHere: 0,
		setAttackCount(num) {
            this.maxAttackCount = num;
        },
        update: function() {
         if (this.model.name == "Starcaller1") {
            const willReset = this.attackResetTimer > 0 && (this.attackResetTimer - ig.system.tick) <= 0;
            if (willReset) {
                this.attackCounterLoop = -1;
            }
        }
            this.parent();
        },
        handleStateStart: function(a, b) {
            this.parent(a, b);
            if (a.startState === 3 && this.model.name == "Starcaller1") {
                if (this.attackResetTimer === 0) {
					this.setAttackCount(2);
					this.counterHere += 1;
					if (this.attackCounter === 2) {
						this.attackCounter -= 2;
					}
					if (this.counterHere === this.maxAttackCount) {
						this.attackCounter = 100;
						this.counterHere = -1;
					}
                }
            }
        }
    });
});