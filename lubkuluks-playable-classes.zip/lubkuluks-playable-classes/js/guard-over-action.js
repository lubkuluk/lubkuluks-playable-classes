ig.ENTITY.Player.inject({
    handleGuard(a, b) {
        function isE(type) {
            return type && Object.keys(type).length == 1 && type.actionKey == 'GUARD_SPECIAL'
        }
        if (
            this.guard.damage < 1 &&
            a.redashReady &&
            !this.actionBlocked.action &&
            (this.charging.time == -1 || isE(this.charging.type)) &&
            !b.guard &&
            !(this.charging.time != -1 && isE(this.charging.type)) &&
            (this.currentAction == this.model.getAction(sc.PLAYER_ACTION.GUARD) || this.currentAction == this.model.getAction(sc.PLAYER_ACTION.PERFECT_GUARD))
        ) {
            if (this.model.name == 'Joern2') {
                var a = sc.ProxyTools.getProxy('shieldOverActionController', this)
                a && a.spawn(this.coll.pos.x, this.coll.pos.y, this.coll.pos.z, this, this.face, true)
            }
            if (this.model.name == 'Starcaller1') {
                var a = sc.ProxyTools.getProxy('shieldOverProxy', this)
                a && a.spawn(this.coll.pos.x, this.coll.pos.y, this.coll.pos.z, this, this.face, true)
            }
            if (this.model.name == 'Hexacast1') {
                var a = sc.ProxyTools.getProxy('shieldOverActionController', this)
                a && a.spawn(this.coll.pos.x, this.coll.pos.y, this.coll.pos.z, this, this.face, true)
            }
            if (this.model.name == 'Hexacast2') {
                var a = sc.ProxyTools.getProxy('shieldOverActionController', this)
                a && a.spawn(this.coll.pos.x, this.coll.pos.y, this.coll.pos.z, this, this.face, true)
            }
            this.cancelAction();
        }
        this.parent(a, b)
    },
    onPlayerShieldBreak: function () {
            sc.stats.addMap("combat", "shieldBreaks", 1);
            this.state = 4;
            if (this.model.name == 'Joern2') {
                var a = sc.ProxyTools.getProxy('guardBrokenProxy', this)
                a && a.spawn(this.coll.pos.x, this.coll.pos.y, this.coll.pos.z, this, this.face, true)
            }
            if (this.model.name == 'Starcaller1') {
                var a = sc.ProxyTools.getProxy('guardBrokenProxy', this)
                a && a.spawn(this.coll.pos.x, this.coll.pos.y, this.coll.pos.z, this, this.face, true)
            }
            this.cancelAction()
        },
})