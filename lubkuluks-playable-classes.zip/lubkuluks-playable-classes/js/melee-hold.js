ig.ENTITY.Player.inject({
        startCloseCombatAction: function (a, b) {
            if (this.dashTimer > 0)
                this.dashBlock = 0.3;
            
            this.dashTimer = 0;
            this.doAttack = false;
            this.gui.crosshair.setActive(false);
            
            this.coll.pos.z == this.coll.baseZPos ?
                this.setAttribute("dashDir", Vec2.assign(this.dashDirData, b.moveDir)) :
                this.setAttribute("dashDir", Vec2.assignC(this.dashDirData, 0, 0));
            
            Vec2.isZero(b.moveDir) || Vec2.assign(this.face, b.moveDir);
            
            // Call trackMeleeInput to start tracking melee button input
            this.trackMeleeInput();
            
            this.doCombatAction(a);
        },
        trackMeleeInput: function () {
            // Check if the melee button is released and set the variable
            var checkMeleeHold = () => {
                if (!sc.control.meleeHold()) {  // Check if the melee button is not being held
                    ig.vars.set("tmp.meleeReleased", true);  // Set the variable to true
                    // Stop checking after the button is released
                    clearInterval(this.meleeInputCheckInterval);  // Stop the interval
                }
            };
        
            // Start checking for the melee button release
            this.meleeInputCheckInterval = setInterval(checkMeleeHold, 100); // Check every 100ms
        },
})