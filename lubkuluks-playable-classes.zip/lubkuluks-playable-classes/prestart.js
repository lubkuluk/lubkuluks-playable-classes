import "./js/combat-tempo-copy.js";
import "./js/custom-bgmQ.js";
import "./js/guard-over-action.js";
import "./js/melee-hold.js";
import "./js/custom-action-buffsQ.js";
import "./js/custom-action-stepsQ.js";
import "./js/custom-font-iconsQ.js";
import "./js/custom-font-icons-LSM.js";
import "./js/custom-assault-LSM.js";
import "./js/custom-ally-entry-LSM.js";




sc.PARTY_OPTIONS.push("Joern2");
//sc.PARTY_OPTIONS.push("Quadroguard1");
sc.PARTY_OPTIONS.push("Quadroguard-Lea");
sc.PARTY_OPTIONS.push("Starcaller1");

sc.COMBAT_CONDITION.HAS_BLOCKED_ENTITY_VAR = ig.Class.extend({
        _wm: new ig.Config({
            attributes: {}
        }),
        init: function () {},
        check: function (a) {
            return (a = a.getTarget()) && a.hasBlockEntity()
        }
    });
sc.COMBAT_CONDITION.HAS_BLOCKED_HITS_VAR = ig.Class.extend({
        _wm: new ig.Config({
            attributes: {}
        }),
        init: function () {},
        check: function (a) {
            return (a = a.getTarget()) && a.combo.guardedHits > 0
        }
    });

sc.PlayerModel.inject({
  onVarAccess: function (a, b) {
   if (b[0] == "player") {
                switch (b[1]) {
                case "modifierRounded":
                    // Get the modifier value
                    var modifierValue = this.params.getModifier(b[2]);

                    var roundedValue = Math.round(modifierValue * 10) / 10;

                    // Return the rounded value as a string
                    return roundedValue.toFixed(1) + "";
                }
            }
            return this.parent(a, b);
        },
});
sc.BasicCombatant.inject({
        onVarAccess: function (a, b) {
            return b[1] == "target" ? ig.vars.forwardEntityVarAccess(this.getTarget(), b, 2) : b[1] == "guardedHits" ? this.combo.guardedHits : this.parent(a, b)
        }
    });
sc.Control.inject({
        meleeHold: function () {
            return this.autoControl ? this.autoControl.get("melee") : ig.input.state("melee") || ig.gamepad.isButtonDown(this._getMeleeButton())
        },
    });
sc.ENEMY_CATEGORY.ALLIES =
        5;

    sc.COMBAT_SWEEPS.STARCALLER = {
        sheet: new ig.EffectSheet("sweeps-starcaller"),
        keys: ["default", "heat", "cold", "shock", "wave"],
        force: {
            radius: 44,
            zHeight: 24,
            centralAngle: 0.5,
            duration: 0.2,
            attack: {
                type: "MEDIUM",
                damageFactor: 0.95,
                spFactor: 1,
                skillBonus: "MELEE_DMG"
            },
            checkCollision: true
        }
    };
    sc.COMBAT_SWEEPS.QUADROGUARD_NERFED = {
        sheet: new ig.EffectSheet("combat.quadroguard"),
        keys: ["shieldNeutral", "shieldHeat",
            "shieldCold", "shieldShock", "shieldWave"],
        fxRotOffset: {
            x: 0,
            y: -20
        },
        force: {
            radius: 40,
            zHeight: 24,
            centralAngle: 0.3,
            duration: 0.1,
            alwaysFull: true,
            attack: {
                type: "HEAVY",
                damageFactor: 1.15,
                spFactor: 1,
                skillBonus: "MELEE_DMG"
            },
            checkCollision: true
        }
    };
    sc.COMBAT_SWEEPS.QUADROGUARD_FINISHER_STRONG = {
        sheet: new ig.EffectSheet("combat.quadroguard"),
        keys: ["shieldNeutralFinisher", "shieldHeatFinisher", "shieldColdFinisher", "shieldShockFinisher", "shieldWaveFinisher"],
        fxRotOffset: {
            x: 0,
            y: -20
        },
        force: {
            radius: 40,
            zHeight: 24,
            centralAngle: 0.3,
            duration: 0.1,
            alwaysFull: true,
            attack: {
                type: "HEAVY",
                damageFactor: 4.25,
                spFactor: 1,
                skillBonus: "MELEE_DMG"
            },
            checkCollision: true
        }
    };
var d = Vec2.create();
sc.BALL_BEHAVIOR.WIRL_SIDEWAYS_CCW = sc.BallBehavior.extend({
        relWirl: 0.2,
        wirlTime: 0.5,
        delay: 0,
        _wm: new ig.Config({
            attributes: {
                relWirl: {
                    _type: "Number",
                    _info: "How much to wirl sideways",
                    _default: 0.2
                },
                wirlTime: {
                    _type: "Number",
                    _info: "How long one whirling takes",
                    _default: 0.5
                },
                delay: {
                    _type: "Number",
                    _info: "Delay before wirling starts",
                    _default: 0
                }
            }
        }),
        init: function (a) {
            this.relWirl = a.relWirl || 0.2;
            this.wirlTime = a.wirlTime || 0.5;
            this.delay = a.delay || 0
        },
        onUpdate: function (a) {
            var b =
                a.maxTime - a.timer;
            if (!(b < this.delay)) {
                var b = b - this.delay,
                b = Math.sin(Math.PI * 2 * b / this.wirlTime + Math.PI * 0.52) * this.relWirl * ig.system.tick * 60,
                f = Vec2.assign(d, a.coll.vel);
                Vec2.rotate90CCW(f);
                Vec2.mulF(f, b);
                Vec2.add(a.coll.vel, f)
            }
        }
    });
    sc.PLAYER_CLASSES = {
        SPHEROMANCER: 0,
        TRIBLADER: 1,
        QUADROGUARD: 2,
        PENTAFIST: 3,
        HEXACAST: 4,
        UNKNOWN: 5,
        STARCALLER: 6
    };
//ig.MessageOverlayGui.Entry.inject({
  //  init(area, name, lookRight, order, displayName) {
    //    if (name == 'main.lea') {
      //      this.beepSound = new ig.Sound('media/sound/move/jump.ogg', 1, 0.02)
       // }
        //this.parent(area, name, lookRight, order, displayName)
    //},
//});
