export default class BasicMod {
	constructor(mod) {
		this.mod = mod;
	}

	async preload() {

	}
	
	async postload() {

	}

	async prestart() {

	}

	async poststart() {
		
	}
}